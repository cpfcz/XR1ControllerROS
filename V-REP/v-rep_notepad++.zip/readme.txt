1.  Place lua.xml into 'C:/Programs (x86)/Notepad++/plugins/APIs' (or similar)
2.  Place langs.xml into 'C:/user/<userName>/AppData/Roaming/Notepad++' (or similar).
    Alternatively, you may also only replace the Lua section in the original langs.xml file